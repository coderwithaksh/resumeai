"""
================================================================
AI CHATBOT SAAS - COMPLETE BACKEND (SINGLE FILE)
================================================================
Sab kuch is ek file mein hai:
  - Config
  - Database Models (SQLite via SQLAlchemy)
  - Email/OTP Service (SMTP)
  - AI Services (Gemini: Text, Code, Image, PPT)
  - Flask Routes (Auth + Chat APIs)

Setup:
  1. pip install -r requirements.txt
     (Flask Flask-SQLAlchemy Flask-Login Flask-Mail Werkzeug
      python-dotenv google-generativeai python-pptx Pillow email-validator)
  2. .env file banayein (neeche REQUIRED ENV VARS section dekhein)
  3. python app.py
  4. Browser: http://localhost:5000
================================================================
"""

import os
import re
import uuid
import random
from datetime import datetime, timedelta

from flask import Flask, request, jsonify, session, send_from_directory, render_template_string
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_mail import Mail, Message as MailMessage
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

import google.generativeai as genai
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

load_dotenv()

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# ================================================================
# REQUIRED ENV VARS (.env file mein daalein)
# ----------------------------------------------------------------
# SECRET_KEY=koi-lamba-random-string
# GEMINI_API_KEY=your-gemini-api-key        (https://ai.google.dev)
# MAIL_SERVER=smtp.gmail.com
# MAIL_PORT=587
# MAIL_USE_TLS=True
# MAIL_USERNAME=youremail@gmail.com
# MAIL_PASSWORD=your-16-digit-gmail-app-password
# MAIL_DEFAULT_SENDER=youremail@gmail.com
# ================================================================

SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-change-me-in-production")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
MAIL_SERVER = os.environ.get("MAIL_SERVER", "smtp.gmail.com")
MAIL_PORT = int(os.environ.get("MAIL_PORT", 587))
MAIL_USE_TLS = os.environ.get("MAIL_USE_TLS", "True") == "True"
MAIL_USERNAME = os.environ.get("MAIL_USERNAME", "")
MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD", "")
MAIL_DEFAULT_SENDER = os.environ.get("MAIL_DEFAULT_SENDER", MAIL_USERNAME)
OTP_EXPIRY_MINUTES = 10

PPT_FOLDER = os.path.join(BASE_DIR, "ppts")
IMAGE_FOLDER = os.path.join(BASE_DIR, "images")

os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)
os.makedirs(PPT_FOLDER, exist_ok=True)
os.makedirs(IMAGE_FOLDER, exist_ok=True)

genai.configure(api_key=GEMINI_API_KEY)
TEXT_MODEL = "gemini-2.0-flash"
IMAGE_MODEL = "gemini-2.0-flash-exp-image-generation"


# ================================================================
# APP SETUP
# ================================================================
app = Flask(__name__)
app.config["SECRET_KEY"] = SECRET_KEY
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'chatbot.db')}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["MAIL_SERVER"] = MAIL_SERVER
app.config["MAIL_PORT"] = MAIL_PORT
app.config["MAIL_USE_TLS"] = MAIL_USE_TLS
app.config["MAIL_USERNAME"] = MAIL_USERNAME
app.config["MAIL_PASSWORD"] = MAIL_PASSWORD
app.config["MAIL_DEFAULT_SENDER"] = MAIL_DEFAULT_SENDER

db = SQLAlchemy(app)
mail = Mail(app)

login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.unauthorized_handler
def unauthorized():
    return jsonify({"success": False, "message": "Pehle login karein."}), 401


# ================================================================
# DATABASE MODELS
# ================================================================
class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    is_verified = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    chats = db.relationship("Chat", backref="user", lazy=True, cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class OTP(db.Model):
    __tablename__ = "otps"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), nullable=False, index=True)
    code = db.Column(db.String(6), nullable=False)
    purpose = db.Column(db.String(20), nullable=False)  # 'signup' or 'reset'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    used = db.Column(db.Boolean, default=False)


class Chat(db.Model):
    __tablename__ = "chats"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title = db.Column(db.String(255), default="New Chat")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    messages = db.relationship("Message", backref="chat", lazy=True, cascade="all, delete-orphan")


class Message(db.Model):
    __tablename__ = "messages"

    id = db.Column(db.Integer, primary_key=True)
    chat_id = db.Column(db.Integer, db.ForeignKey("chats.id"), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'user' or 'assistant'
    msg_type = db.Column(db.String(20), default="text")  # text, code, image, ppt
    content = db.Column(db.Text, nullable=False)
    file_path = db.Column(db.String(500), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


with app.app_context():
    db.create_all()


# ================================================================
# EMAIL / OTP SERVICE
# ================================================================
def generate_otp_code():
    return f"{random.randint(100000, 999999)}"


def create_and_send_otp(email, purpose="signup"):
    code = generate_otp_code()
    expires_at = datetime.utcnow() + timedelta(minutes=OTP_EXPIRY_MINUTES)

    otp = OTP(email=email, code=code, purpose=purpose, expires_at=expires_at)
    db.session.add(otp)
    db.session.commit()

    subject = "Aapka OTP Code - AI Chatbot" if purpose == "signup" else "Password Reset OTP - AI Chatbot"
    body = (
        f"Namaste,\n\n"
        f"Aapka OTP code hai: {code}\n\n"
        f"Yeh code agle {OTP_EXPIRY_MINUTES} minute ke liye valid hai.\n"
        f"Agar yeh request aapne nahi ki, to is email ko ignore karein.\n\n"
        f"Dhanyavaad,\nAI Chatbot Team"
    )
    msg = MailMessage(subject=subject, recipients=[email], body=body)
    mail.send(msg)
    return code


def verify_otp_code(email, code, purpose="signup"):
    otp = (
        OTP.query.filter_by(email=email, code=code, purpose=purpose, used=False)
        .order_by(OTP.created_at.desc())
        .first()
    )
    if not otp:
        return False
    if otp.expires_at < datetime.utcnow():
        return False
    otp.used = True
    db.session.commit()
    return True


# ================================================================
# AI SERVICES (Gemini: Text, Code, Image, PPT)
# ================================================================
def ai_generate_text(prompt, history=None):
    model = genai.GenerativeModel(TEXT_MODEL)
    chat_history = []
    if history:
        for h in history:
            role = "user" if h["role"] == "user" else "model"
            chat_history.append({"role": role, "parts": [h["content"]]})
    chat = model.start_chat(history=chat_history)
    response = chat.send_message(prompt)
    return response.text


def ai_generate_code(prompt, language="python"):
    model = genai.GenerativeModel(TEXT_MODEL)
    full_prompt = (
        f"You are an expert {language} developer. "
        f"Generate clean, well-commented {language} code for this request:\n\n"
        f"{prompt}\n\n"
        f"Return ONLY the code inside a single markdown code block. "
        f"Add a short explanation after the code block."
    )
    response = model.generate_content(full_prompt)
    return response.text


def ai_generate_image(prompt):
    model = genai.GenerativeModel(IMAGE_MODEL)
    response = model.generate_content(
        prompt,
        generation_config={"response_modalities": ["TEXT", "IMAGE"]},
    )

    filename = f"{uuid.uuid4().hex}.png"
    filepath = os.path.join(IMAGE_FOLDER, filename)

    for part in response.candidates[0].content.parts:
        if hasattr(part, "inline_data") and part.inline_data is not None:
            with open(filepath, "wb") as f:
                f.write(part.inline_data.data)
            return f"images/{filename}"

    raise ValueError("Gemini ne image return nahi ki. Prompt badal kar dobara try karein.")


def _parse_ppt_outline(raw_text):
    slides = []
    blocks = re.split(r"SLIDE\s*\d+", raw_text, flags=re.IGNORECASE)
    for block in blocks:
        block = block.strip()
        if not block:
            continue
        title_match = re.search(r"TITLE:\s*(.+)", block)
        content_match = re.search(r"CONTENT:\s*(.+)", block, flags=re.DOTALL)
        title = title_match.group(1).strip() if title_match else "Slide"
        content_raw = content_match.group(1).strip() if content_match else ""
        bullets = [b.strip(" -") for b in content_raw.split("|") if b.strip()]
        slides.append({"title": title, "bullets": bullets})
    return slides


def ai_generate_ppt(topic, num_slides=6):
    model = genai.GenerativeModel(TEXT_MODEL)
    prompt = (
        f"Create an outline for a {num_slides}-slide presentation on: '{topic}'. "
        f"Format STRICTLY like this for every slide, nothing else:\n\n"
        f"SLIDE 1\nTITLE: <short title>\nCONTENT: point one | point two | point three\n\n"
        f"SLIDE 2\nTITLE: ...\nCONTENT: ...\n\n"
        f"Keep each bullet under 12 words. First slide should be a title/intro slide, "
        f"last slide should be a conclusion/summary slide."
    )
    response = model.generate_content(prompt)
    slides_data = _parse_ppt_outline(response.text)

    if not slides_data:
        raise ValueError("PPT outline generate nahi ho paaya. Dobara try karein.")

    prs = Presentation()
    prs.slide_width = Inches(13.33)
    prs.slide_height = Inches(7.5)

    PRIMARY = RGBColor(0x1E, 0x27, 0x61)
    ACCENT_TXT = RGBColor(0xFF, 0xFF, 0xFF)
    TEXT_DARK = RGBColor(0x21, 0x21, 0x21)
    ACCENT_DOT = RGBColor(0xFF, 0x7A, 0x59)

    blank_layout = prs.slide_layouts[6]

    for idx, slide_data in enumerate(slides_data):
        slide = prs.slides.add_slide(blank_layout)
        is_title_slide = idx == 0

        if is_title_slide:
            bg = slide.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
            bg.fill.solid()
            bg.fill.fore_color.rgb = PRIMARY
            bg.line.fill.background()
            bg.shadow.inherit = False

            dot = slide.shapes.add_shape(9, Inches(1), Inches(2.45), Inches(0.18), Inches(0.18))
            dot.fill.solid()
            dot.fill.fore_color.rgb = ACCENT_DOT
            dot.line.fill.background()
            dot.shadow.inherit = False

            title_box = slide.shapes.add_textbox(Inches(1), Inches(2.8), Inches(11.33), Inches(2))
            tf = title_box.text_frame
            tf.word_wrap = True
            p = tf.paragraphs[0]
            p.alignment = PP_ALIGN.LEFT
            p.text = slide_data["title"]
            p.font.size = Pt(44)
            p.font.bold = True
            p.font.color.rgb = ACCENT_TXT
            p.font.name = "Calibri"
        else:
            dot = slide.shapes.add_shape(9, Inches(0.62), Inches(1.15), Inches(0.14), Inches(0.14))
            dot.fill.solid()
            dot.fill.fore_color.rgb = ACCENT_DOT
            dot.line.fill.background()
            dot.shadow.inherit = False

            title_box = slide.shapes.add_textbox(Inches(0.6), Inches(0.5), Inches(12), Inches(1))
            tf = title_box.text_frame
            p = tf.paragraphs[0]
            p.alignment = PP_ALIGN.LEFT
            p.text = slide_data["title"]
            p.font.size = Pt(32)
            p.font.bold = True
            p.font.color.rgb = PRIMARY
            p.font.name = "Calibri"

            content_box = slide.shapes.add_textbox(Inches(0.8), Inches(2.0), Inches(7.2), Inches(5))
            tf = content_box.text_frame
            tf.word_wrap = True
            for i, bullet in enumerate(slide_data["bullets"]):
                p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
                p.alignment = PP_ALIGN.LEFT
                p.text = f"•  {bullet}"
                p.font.size = Pt(20)
                p.font.color.rgb = TEXT_DARK
                p.font.name = "Calibri"
                p.space_after = Pt(14)

            panel = slide.shapes.add_shape(1, Inches(8.6), Inches(2.0), Inches(4.0), Inches(4.0))
            panel.fill.solid()
            panel.fill.fore_color.rgb = RGBColor(0xF2, 0xF3, 0xF8)
            panel.line.fill.background()
            panel.shadow.inherit = False
            num_tf = panel.text_frame
            num_tf.word_wrap = True
            np_ = num_tf.paragraphs[0]
            np_.alignment = PP_ALIGN.CENTER
            np_.text = f"{idx + 1:02d}"
            np_.font.size = Pt(60)
            np_.font.bold = True
            np_.font.color.rgb = PRIMARY
            np_.font.name = "Calibri"

    filename = f"{uuid.uuid4().hex}.pptx"
    filepath = os.path.join(PPT_FOLDER, filename)
    prs.save(filepath)
    return f"ppts/{filename}"


# ================================================================
# HELPER: chat history for multi-turn context
# ================================================================
def _get_history_for_chat(chat_id, limit=20):
    msgs = (
        Message.query.filter_by(chat_id=chat_id)
        .order_by(Message.created_at.asc())
        .limit(limit)
        .all()
    )
    return [{"role": m.role, "content": m.content} for m in msgs if m.msg_type == "text"]


# ================================================================
# ROUTES: PAGE (serves the single frontend file)
# ================================================================
@app.route("/")
def home():
    with open(os.path.join(BASE_DIR, "index.html"), "r", encoding="utf-8") as f:
        html = f.read()
    return render_template_string(html)


# ================================================================
# ROUTES: AUTH API
# ================================================================
@app.route("/api/auth/signup", methods=["POST"])
def api_signup():
    data = request.get_json()
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    confirm = data.get("confirm_password") or ""

    if not name or not email or not password:
        return jsonify({"success": False, "message": "Saare fields bharna zaroori hai."}), 400
    if password != confirm:
        return jsonify({"success": False, "message": "Password match nahi kar raha."}), 400
    if len(password) < 6:
        return jsonify({"success": False, "message": "Password kam se kam 6 characters ka hona chahiye."}), 400

    existing = User.query.filter_by(email=email).first()
    if existing and existing.is_verified:
        return jsonify({"success": False, "message": "Is email se account pehle se bana hua hai. Login karein."}), 400

    if not existing:
        user = User(name=name, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
    else:
        existing.name = name
        existing.set_password(password)
        db.session.commit()

    try:
        create_and_send_otp(email, purpose="signup")
    except Exception as e:
        return jsonify({"success": False, "message": f"OTP email bhejne mein dikkat aayi: {e}"}), 500

    session["pending_email"] = email
    return jsonify({"success": True, "message": "OTP aapke email par bhej diya gaya hai.", "email": email})


@app.route("/api/auth/verify-otp", methods=["POST"])
def api_verify_otp():
    data = request.get_json()
    code = (data.get("otp") or "").strip()
    email = session.get("pending_email") or data.get("email")

    if not email:
        return jsonify({"success": False, "message": "Session expire ho gaya. Dobara signup karein."}), 400

    if verify_otp_code(email, code, purpose="signup"):
        user = User.query.filter_by(email=email).first()
        user.is_verified = True
        db.session.commit()
        session.pop("pending_email", None)
        return jsonify({"success": True, "message": "Email verify ho gaya! Ab login karein."})
    else:
        return jsonify({"success": False, "message": "OTP galat hai ya expire ho gaya hai."}), 400


@app.route("/api/auth/resend-otp", methods=["POST"])
def api_resend_otp():
    data = request.get_json() or {}
    email = session.get("pending_email") or session.get("reset_email") or data.get("email")
    purpose = "reset" if session.get("reset_email") else "signup"

    if not email:
        return jsonify({"success": False, "message": "Session expire ho gaya."}), 400
    try:
        create_and_send_otp(email, purpose=purpose)
        return jsonify({"success": True, "message": "OTP dobara bhej diya gaya."})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route("/api/auth/login", methods=["POST"])
def api_login():
    data = request.get_json()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    user = User.query.filter_by(email=email).first()
    if not user or not user.check_password(password):
        return jsonify({"success": False, "message": "Email ya password galat hai."}), 400

    if not user.is_verified:
        session["pending_email"] = email
        try:
            create_and_send_otp(email, purpose="signup")
        except Exception:
            pass
        return jsonify({"success": False, "message": "Pehle apna email verify karein.", "need_verification": True, "email": email}), 403

    login_user(user)
    return jsonify({"success": True, "message": "Login successful!", "user": {"name": user.name, "email": user.email}})


@app.route("/api/auth/forgot-password", methods=["POST"])
def api_forgot_password():
    data = request.get_json()
    email = (data.get("email") or "").strip().lower()

    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({"success": False, "message": "Is email se koi account nahi mila."}), 400

    try:
        create_and_send_otp(email, purpose="reset")
    except Exception as e:
        return jsonify({"success": False, "message": f"OTP bhejne mein dikkat: {e}"}), 500

    session["reset_email"] = email
    return jsonify({"success": True, "message": "Password reset OTP bhej diya gaya hai.", "email": email})


@app.route("/api/auth/reset-password", methods=["POST"])
def api_reset_password():
    data = request.get_json()
    email = session.get("reset_email") or data.get("email")
    code = (data.get("otp") or "").strip()
    new_password = data.get("new_password") or ""
    confirm = data.get("confirm_password") or ""

    if not email:
        return jsonify({"success": False, "message": "Session expire ho gaya. Dobara try karein."}), 400
    if new_password != confirm:
        return jsonify({"success": False, "message": "Password match nahi kar raha."}), 400
    if len(new_password) < 6:
        return jsonify({"success": False, "message": "Password kam se kam 6 characters ka hona chahiye."}), 400
    if not verify_otp_code(email, code, purpose="reset"):
        return jsonify({"success": False, "message": "OTP galat hai ya expire ho gaya hai."}), 400

    user = User.query.filter_by(email=email).first()
    user.set_password(new_password)
    db.session.commit()
    session.pop("reset_email", None)

    return jsonify({"success": True, "message": "Password reset ho gaya! Ab login karein."})


@app.route("/api/auth/logout", methods=["POST"])
@login_required
def api_logout():
    logout_user()
    return jsonify({"success": True})


@app.route("/api/auth/me", methods=["GET"])
def api_me():
    if current_user.is_authenticated:
        return jsonify({"authenticated": True, "user": {"name": current_user.name, "email": current_user.email}})
    return jsonify({"authenticated": False})


# ================================================================
# ROUTES: CHAT MANAGEMENT API
# ================================================================
@app.route("/api/chats/new", methods=["POST"])
@login_required
def new_chat():
    chat = Chat(user_id=current_user.id, title="New Chat")
    db.session.add(chat)
    db.session.commit()
    return jsonify({"success": True, "chat_id": chat.id, "title": chat.title})


@app.route("/api/chats", methods=["GET"])
@login_required
def list_chats():
    chats = Chat.query.filter_by(user_id=current_user.id).order_by(Chat.updated_at.desc()).all()
    return jsonify({"chats": [{"id": c.id, "title": c.title, "updated_at": c.updated_at.isoformat()} for c in chats]})


@app.route("/api/chats/search", methods=["GET"])
@login_required
def search_chats():
    query = request.args.get("q", "").strip()
    if not query:
        return jsonify({"chats": []})
    chats = (
        Chat.query.filter(Chat.user_id == current_user.id, Chat.title.ilike(f"%{query}%"))
        .order_by(Chat.updated_at.desc())
        .all()
    )
    return jsonify({"chats": [{"id": c.id, "title": c.title, "updated_at": c.updated_at.isoformat()} for c in chats]})


@app.route("/api/chats/<int:chat_id>", methods=["GET"])
@login_required
def get_chat(chat_id):
    chat = Chat.query.filter_by(id=chat_id, user_id=current_user.id).first_or_404()
    messages = Message.query.filter_by(chat_id=chat.id).order_by(Message.created_at.asc()).all()
    return jsonify({
        "chat_id": chat.id,
        "title": chat.title,
        "messages": [
            {"role": m.role, "type": m.msg_type, "content": m.content, "file_path": m.file_path, "created_at": m.created_at.isoformat()}
            for m in messages
        ],
    })


@app.route("/api/chats/<int:chat_id>", methods=["DELETE"])
@login_required
def delete_chat(chat_id):
    chat = Chat.query.filter_by(id=chat_id, user_id=current_user.id).first_or_404()
    db.session.delete(chat)
    db.session.commit()
    return jsonify({"success": True})


# ================================================================
# ROUTES: AI GENERATION API
# ================================================================
@app.route("/api/generate/text", methods=["POST"])
@login_required
def api_generate_text():
    data = request.get_json()
    prompt = (data.get("prompt") or "").strip()
    chat_id = data.get("chat_id")

    if not prompt:
        return jsonify({"success": False, "message": "Prompt khaali nahi ho sakta."}), 400

    chat = Chat.query.filter_by(id=chat_id, user_id=current_user.id).first_or_404()
    history = _get_history_for_chat(chat.id)

    db.session.add(Message(chat_id=chat.id, role="user", msg_type="text", content=prompt))

    try:
        reply = ai_generate_text(prompt, history=history)
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": f"AI error: {e}"}), 500

    db.session.add(Message(chat_id=chat.id, role="assistant", msg_type="text", content=reply))

    if chat.title == "New Chat":
        chat.title = prompt[:50]
    chat.updated_at = datetime.utcnow()
    db.session.commit()

    return jsonify({"success": True, "reply": reply, "title": chat.title})


@app.route("/api/generate/code", methods=["POST"])
@login_required
def api_generate_code():
    data = request.get_json()
    prompt = (data.get("prompt") or "").strip()
    language = data.get("language", "python")
    chat_id = data.get("chat_id")

    if not prompt:
        return jsonify({"success": False, "message": "Prompt khaali nahi ho sakta."}), 400

    chat = Chat.query.filter_by(id=chat_id, user_id=current_user.id).first_or_404()
    db.session.add(Message(chat_id=chat.id, role="user", msg_type="text", content=prompt))

    try:
        reply = ai_generate_code(prompt, language=language)
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": f"AI error: {e}"}), 500

    db.session.add(Message(chat_id=chat.id, role="assistant", msg_type="code", content=reply))

    if chat.title == "New Chat":
        chat.title = f"Code: {prompt[:40]}"
    chat.updated_at = datetime.utcnow()
    db.session.commit()

    return jsonify({"success": True, "reply": reply, "title": chat.title})


@app.route("/api/generate/image", methods=["POST"])
@login_required
def api_generate_image():
    data = request.get_json()
    prompt = (data.get("prompt") or "").strip()
    chat_id = data.get("chat_id")

    if not prompt:
        return jsonify({"success": False, "message": "Prompt khaali nahi ho sakta."}), 400

    chat = Chat.query.filter_by(id=chat_id, user_id=current_user.id).first_or_404()
    db.session.add(Message(chat_id=chat.id, role="user", msg_type="text", content=prompt))

    try:
        rel_path = ai_generate_image(prompt)
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": f"Image generation error: {e}"}), 500

    db.session.add(Message(chat_id=chat.id, role="assistant", msg_type="image", content=prompt, file_path=rel_path))

    if chat.title == "New Chat":
        chat.title = f"Image: {prompt[:40]}"
    chat.updated_at = datetime.utcnow()
    db.session.commit()

    return jsonify({"success": True, "file_path": rel_path, "title": chat.title})


@app.route("/api/generate/ppt", methods=["POST"])
@login_required
def api_generate_ppt():
    data = request.get_json()
    topic = (data.get("topic") or "").strip()
    num_slides = int(data.get("num_slides", 6))
    chat_id = data.get("chat_id")

    if not topic:
        return jsonify({"success": False, "message": "Topic khaali nahi ho sakta."}), 400

    num_slides = max(3, min(num_slides, 15))
    chat = Chat.query.filter_by(id=chat_id, user_id=current_user.id).first_or_404()
    db.session.add(Message(chat_id=chat.id, role="user", msg_type="text", content=f"PPT: {topic}"))

    try:
        rel_path = ai_generate_ppt(topic, num_slides=num_slides)
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": f"PPT generation error: {e}"}), 500

    db.session.add(Message(chat_id=chat.id, role="assistant", msg_type="ppt", content=topic, file_path=rel_path))

    if chat.title == "New Chat":
        chat.title = f"PPT: {topic[:40]}"
    chat.updated_at = datetime.utcnow()
    db.session.commit()

    return jsonify({"success": True, "file_path": rel_path, "title": chat.title})


# ================================================================
# ROUTES: FILE SERVING
# ================================================================
@app.route("/images/<path:filename>")
@login_required
def serve_image(filename):
    return send_from_directory(IMAGE_FOLDER, filename)


@app.route("/ppts/<path:filename>")
@login_required
def serve_ppt(filename):
    return send_from_directory(PPT_FOLDER, filename, as_attachment=True)


# ================================================================
# RUN
# ================================================================
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
