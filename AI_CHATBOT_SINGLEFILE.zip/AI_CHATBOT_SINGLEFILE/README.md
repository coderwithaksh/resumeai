# AI Chatbot SaaS — Single-File Version

Sirf **2 main files**:

| File | Kya hai |
|---|---|
| `app.py` | **Complete Backend** — Config, Database Models, Email/OTP Service, Gemini AI Services (Text/Code/Image/PPT), saare Flask Routes — sab ek file mein |
| `index.html` | **Complete Frontend** — HTML + CSS (`<style>`) + JavaScript (`<script>`) sab ek file mein. Single Page App: Login/Signup/OTP/Forgot/Reset/Dashboard sab isi file mein, JS se show/hide hote hain |

Plus 2 chhoti support files: `requirements.txt` aur `.env.example`.

---

## 📁 Folder Structure

```
AI_CHATBOT_SINGLEFILE/
├── app.py              ← Poora backend
├── index.html           ← Poora frontend
├── requirements.txt
├── .env.example
├── ppts/                ← generated PPT files yahan save hongi
├── images/               ← generated images yahan save hongi
└── instance/
    └── chatbot.db          ← SQLite database (auto-create hoga)
```

`app.py` khud `index.html` ko serve karta hai (`/` route par) — koi `templates/` ya `static/` folder ki zaroorat nahi.

---

## 🔑 Step 1: API Keys

### Gemini API Key (Text + Code + Image)
1. **https://ai.google.dev** par jayein → **Get API Key** → **Create API Key**
2. Key copy karke `.env` mein `GEMINI_API_KEY` mein daalein

### Gmail App Password (OTP email ke liye)
1. **https://myaccount.google.com/security** → **2-Step Verification** ON karein
2. **App Passwords** (https://myaccount.google.com/apppasswords) → naam likhein → **Generate**
3. 16-digit password ko `.env` mein `MAIL_PASSWORD` mein daalein (spaces hata kar)

---

## ⚙️ Step 2: Setup

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt

cp .env.example .env
# Ab .env file kholein aur GEMINI_API_KEY, MAIL_USERNAME, MAIL_PASSWORD bharein
```

## ▶️ Step 3: Run

```bash
python app.py
```

Browser: **http://localhost:5000**

---

## ✅ Maine Test Kiya Hai (sab pass)

- Signup → OTP generate + email (mocked test mein verify kiya) → wrong OTP reject → correct OTP verify
- Login (verified user) / login block (unverified user)
- Forgot password → OTP → reset → naye password se login, purane se login fail
- Logout ke baad protected routes clean `401 JSON` dete hain (crash nahi karte)
- New Chat, Text generation, Code generation, Chat history retrieval, Chat search, Chat delete
- PPT generation (asli `python-pptx` file ban kar download bhi hui — 31KB valid .pptx file)

---

## 🔧 Architecture Notes

- **Single Page App**: `index.html` mein 6 "pages" hain (`#page-login`, `#page-signup`, etc.) jo JS se `hidden` class ke through show/hide hoti hain — koi page reload nahi hota.
- **API-first backend**: Saare routes `/api/...` JSON return karte hain (HTML render nahi karte) — sirf `/` route HTML serve karta hai.
- **Auth check on load**: Page load hote hi `/api/auth/me` call hoti hai — agar already logged in hain (session cookie valid hai) to seedha dashboard khulta hai.
- **Database**: SQLite, `instance/chatbot.db` mein — pehli run par auto-create hota hai.

---

## ⚠️ Security Notes

- `.env` kabhi commit na karein
- Production mein `SECRET_KEY` strong random value rakhein
- Production mein `app.run(debug=False)` karein
